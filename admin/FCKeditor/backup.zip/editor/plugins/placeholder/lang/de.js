﻿/*
 * FCKeditor - The text editor for internet
 * Copyright (C) 2003-2006 Frederico Caldeira Knabben
 * 
 * Licensed under the terms of the GNU Lesser General Public License:
 * 		http://www.opensource.org/licenses/lgpl-license.php
 * 
 * For further information visit:
 * 		http://www.fckeditor.net/
 * 
 * "Support Open Source software. What about a donation today?"
 * 
 * File Name: de.js
 * 	Placholder German language file.
 * 
 * File Authors:
 * 		José Fontanil
 */
FCKLang.PlaceholderBtn			= 'Einfügen/editieren Platzhalter' ;
FCKLang.PlaceholderDlgTitle		= 'Platzhalter Eigenschaften' ;
FCKLang.PlaceholderDlgName		= 'Platzhalter Name' ;
FCKLang.PlaceholderErrNoName	= 'Bitte den Namen des Platzhalters schreiben' ;
FCKLang.PlaceholderErrNameInUse	= 'Der angegebene Namen ist schon in Gebrauch' ;